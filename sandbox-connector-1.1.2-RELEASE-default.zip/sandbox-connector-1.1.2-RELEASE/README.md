# DevPops Client

The DevPoPs Client is a proxy server that routes bidirectional requests 
between your development machine and the Akamai network via a secure gateway. 
Use it in conjunction with the DevPoPs API to create a sandbox environment 
for testing.

### Requirements

Java 8 or later.

JAVA_HOME environment variable pointing to your Java installation. 
(e.g. /Library/Java/JavaVirtualMachines/jdk1.8.0_112.jdk/Contents/Home)

### Description of files and folders

```
.
├── README.md
├── bin
│   ├── connector.sh <-- Linux/Mac script to launch client
│   └── connector.bat <-- Windows script to launch client
├── conf
│   ├── config.json <-- proxy configuration 
│   └── logback.xml <-- logging configuration
├── lib
│   └── sandbox-connector.jar
└── logs <-- client will write logs here
```

### Configuring the Client

The configuration file `config.json` has three sections:

* `connectorServerInfo` - Describes how the DevPoPs Client should 
serve traffic. What port and host should the client listen on? Is content 
HTTP or HTTPS?

    ```
    {
    "connectorServerInfo":
    "secure": false,
    "port": 9550,
    "host": "127.0.0.1"
    },
    ```

	> **NOTE**: If you set `"secure": true`, the client will automatically generate a self-signed certificate. 
If you have a custom certificate, modify the `config.json` file to include the `certChainPath` and `keyPath` for your certificate as shown.

   ```
    "connectorServerInfo": {
    "secure": true,
    "port": 9550,
    "host": "127.0.0.1",
    "cert": {
      "certChainPath": "/Users/asmith/Desktop/cert/example.crt",
      "keyPath": "/Users/asmith/Desktop/cert/example.key"
    }
   ```

* `originMappings` - List that maps origin requests coming from Akamai 
to the proxy destination. You can include more than one hostname in 
a sandbox. You can opt to use a string format for the `to` field as shown.
You can use the `*` character to represent a  wildcard for the origin server.

    ```
  "originMappings": [
    {
      "from": "<ORIGIN HOST>",
      "to": {
        "secure": false, 
        "port": 8080,
        "host": "localhost"
      }
    }, {
      "from": "test1.dev.example.com",
      "to": "http://localhost:8083"
    }, {
      "from": "*.dev.example.com",
      "to": "http://localhost:8081"
    }
  ]
    ```

	> **NOTE**: If you omit the `to` line, the port and hostname will be determined by the Akamai edge server
based on the property configuration within the sandbox.

* jwt - The Java Web Token that enables you to securely connect to your sandbox. 
Create this with the DevPoPs API, then paste it into the `config.json` file.

    ```
    "jwt": "<ENTER JWT HERE>"
    ```

Modify the `config.json` file as required for your dev environment.

For example, if your Akamai configuration makes origin requests to `origin-dev.example.com` 
and you would like that to resolve to a `http://localhost:8080` so you can test in your 
local dev environment, use this as an origin mapping:

```
 "originMappings": [
    {
      "from": "origin-dev.example.com", <-- hostname for origin requests
      "to": {  <-- where to proxy the requests
        "secure": false, 
        "port": 8080,
        "host": "localhost"
      }
    }
  ]
```

If your Akamai configuration contains more than one hostname 
for origin requests, create a node for each. If you want 
Akamai to fetch the content for a given hostname from the origin (not a proxy), 
put the same hostname in `from` and `host` as shown below:

```
 "originMappings": [
    {
      "from": "origin-dev.example.com",
      "to": {  
        "secure": false, 
        "port": 8080,
        "host": "localhost"
      }
    }, {
      "from": "origin-static.example.com",
      "to": "origin-static.example.com"
    }
  ]
```

### Starting the DevPoPs Client

In Terminal, run the script appropriate for your operating system.

| Script | Operating System |
| --- | --- |
| connector.bat | Windows |
| connector.sh | Linux/Mac |